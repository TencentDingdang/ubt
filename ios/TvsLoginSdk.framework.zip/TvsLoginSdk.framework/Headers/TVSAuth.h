//
//  TVSAuth.h
//  TvsLoginSdk
//
//  Created by RincLiu on 21/08/2017.
//  Copyright © 2017 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TVSAuthDelegate.h"

/*!
 * @class UserInfo
 * @brief 用户信息
 */
@interface UserInfo : NSObject
/*!
 * @brief id类型（0：微信，1：QQ）
 */
@property(nonatomic,assign) NSInteger idType;
/*!
 * @brief 昵称
 */
@property(nonatomic,copy) NSString* nickName;
/*!
 * @brief 头像
 */
@property(nonatomic,copy) NSString* headImgUrl;
/*!
 * @brief 性别（0：女，1：男）
 */
@property(nonatomic,assign) NSInteger sex;
/*!
 * @brief 
 */
@property(nonatomic,assign) NSString *unionId;

@end

/*!
 * @class TVSAuth
 * @brief TVS 授权 API
 */
@interface TVSAuth : NSObject

/*!
 * @brief TVS 授权回调协议
 * @warning 如果要接收授权回调事件，必须实现此协议
 */
@property(nonatomic,weak) id<TVSAuthDelegate> authDelegate;

/*!
 * @brief 获得 TVS 授权帮助类单例对象
 * @return TVS 授权帮助类实例
 */
+(instancetype)shared;

/*!
 * @brief 注册 AppId (自动从 Info.plist 读取)
 * @warning 必须在 AppDelegate 的 application:didFinishLaunchingWithOptions: 方法中调用
 * @param productId 
 * @param dsn 
 * @return 是否注册成功，如果失败，请首先检查 Info.plist 是否注册微信或 QQ 的 AppId
 */
-(BOOL)registerWithProductId:(NSString*)productId DSN:(NSString*)dsn;

/*!
 * @brief 处理 URL 跳转
 * @warning 必须在 AppDelegate 的 application:handleOpenURL: 和 application:openURL:sourceApplication:annotation: 两个方法中调用
 * @param url 待处理的 URL
 * @return 是否成功处理相关 URL 跳转
 */
-(BOOL)handleOpenUrl:(NSURL*)url;

/*!
 * @brief 检查微信 Token 是否存在
 * @return 是否存在
 */
-(BOOL)isWXTokenExist;

/*!
 * @brief 检查 QQ Token 是否存在
 * @return 是否存在
 */
-(BOOL)isQQTokenExist;

/*!
 * @brief 微信登录
 * @warning 如果微信 token 不存在，则必须调用此方法，以获得 TVS ClientId
 */
-(void)loginWithWX;

/*!
 * @brief QQ 登录
 * @warning 如果 QQ token 不存在，则必须调用此方法，以获得 TVS ClientId
 */
-(void)loginWithQQ;

/*!
 * @brief 刷新微信 Token
 * @warning 如果微信 token 存在，则必须调用此方法，以获得 TVS ClientId
 */
-(void)refreshWXToken;

/*!
 * @brief 验证 QQ Token
 * @warning 如果 QQ token 存在，则必须调用此方法，以获得 TVS ClientId
 */
-(void)verifyQQToken;

/*!
 * @brief 获取 TVS 平台返回的 ClientId
 * @return TVS 平台返回的 ClientId
 */
-(NSString*)clientId;

/*!
 * @brief 获取 userid
 * @return userId
 */
-(NSString*)userId;

/*!
 * @brief 获取用户信息
 * @return userInfo
 */
-(UserInfo*)userInfo;

/*!
 * @brief 获取微信/QQ登录的 openID
 * @return 微信/QQ登录的 openID
 */
-(NSString*)openId;

/*!
 * @brief 获取微信/QQ登录的 accessToken
 * @return 微信/QQ登录的 accessToken
 */
-(NSString*)accessToken;

/*!
 * @brief 获取微信登录的 refreshToken
 * @return 微信登录的 refreshToken
 */
-(NSString*)refreshToken;

/*!
 * @brief 获取微信/QQ token 的过期时间
 * @return 微信/QQ token 的过期时间
 */
-(NSInteger)expireTime;

/*!
 * @brief 设置 TVS 网络请求是否测试环境
 * @param isTstEnv 是否测试环境
 */
-(void)setTestEnvironment:(BOOL)isTstEnv;

/*!
 * @brief 注销登录
 */
-(void)logout;

@end
